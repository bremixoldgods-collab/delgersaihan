// ============================
// Үндсэн App компонент
// ============================

import { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import HomePage from "./pages/HomePage";
import VideoPlayerPage from "./pages/VideoPlayerPage";

const App = () => {
  // Sidebar нээлттэй эсэх
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setIsSidebarOpen((prev) => !prev);
  };

  return (
    <BrowserRouter>
      {/* Үндсэн layout: Header + Sidebar + Агуулга */}
      <div className="min-h-screen bg-[#0f0f0f] flex flex-col">

        {/* ─── Дээд цэс (fixed) ─── */}
        <Header onMenuToggle={toggleSidebar} isSidebarOpen={isSidebarOpen} />

        {/* ─── Гол хэсэг: Sidebar + Агуулга ─── */}
        <div className="flex flex-1 pt-14">

          {/* ─── Хажуугийн цэс ─── */}
          <Sidebar isOpen={isSidebarOpen} />

          {/* ─── Үндсэн агуулга ─── */}
          <main
            className={`flex-1 min-w-0 transition-all duration-300 ${
              isSidebarOpen ? "lg:ml-60" : "ml-0"
            }`}
          >
            <Routes>
              {/* Нүүр хуудас */}
              <Route path="/" element={<HomePage />} />

              {/* Видео үзэх хуудас */}
              <Route path="/video/:id" element={<VideoPlayerPage />} />

              {/* 404 хуудас */}
              <Route
                path="*"
                element={
                  <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
                    <div className="text-8xl mb-6">🎬</div>
                    <h2 className="text-white text-3xl font-bold mb-3">
                      404 - Хуудас олдсонгүй
                    </h2>
                    <p className="text-gray-400 text-base mb-6 max-w-md">
                      Та хайсан хуудас байхгүй байна. Нүүр хуудас руу буцаж
                      үзнэ үү.
                    </p>
                    <a
                      href="/"
                      className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-full font-semibold transition-colors"
                    >
                      🏠 Нүүр хуудас
                    </a>
                  </div>
                }
              />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
};

export default App;
