// ========================
// Төрлийн тодорхойлолтууд
// ========================

export interface Video {
  id: string;
  title: string;           // Монгол гарчиг
  channelName: string;     // Сувгийн нэр
  channelAvatar: string;   // Сувгийн зураг URL
  thumbnail: string;       // Thumbnail зураг URL
  views: string;           // Үзэлтийн тоо (жишээ: "1.2М")
  uploadedAt: string;      // Байршуулсан хугацаа
  duration: string;        // Видеоны урт (жишээ: "10:25")
  description: string;     // Тайлбар
  likes: string;           // Таалагдсан тоо
  category: string;        // Ангилал
  subscribers: string;     // Дагагчдын тоо
  videoUrl?: string;       // Жинхэнэ видео URL (заавал биш)
  comments: Comment[];     // Сэтгэгдлүүд
}

export interface Comment {
  id: string;
  author: string;          // Сэтгэгдэл бичсэн хүн
  avatar: string;          // Сэтгэгдэл бичсэн хүний зураг
  text: string;            // Сэтгэгдлийн текст
  likes: number;           // Сэтгэгдлийн таалагдал
  time: string;            // Хэзээ бичсэн
}

export interface Category {
  id: string;
  label: string;           // Ангилалын нэр (Монголоор)
}
