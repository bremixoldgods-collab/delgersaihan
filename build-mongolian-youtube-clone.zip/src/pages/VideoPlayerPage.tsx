// ====================================
// АЛХАМ 5: Бичлэг үзэх хуудас
// ====================================

import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  AiOutlineLike,
  AiOutlineDislike,
  AiOutlineShareAlt,
  AiOutlineDownload,
  AiOutlineEllipsis,
  AiOutlineBell,
  AiOutlineSend,
  AiOutlineArrowLeft,
  AiOutlineLike as LikeFilled,
} from "react-icons/ai";
import { MdOutlinePlaylistAdd, MdOutlineSort } from "react-icons/md";

import { videos } from "../data/videos";

const VideoPlayerPage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Идэвхтэй видео
  const video = videos.find((v) => v.id === id);

  // State-үүд
  const [isLiked, setIsLiked] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [showFullDesc, setShowFullDesc] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [comments, setComments] = useState(video?.comments || []);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Санал болгосон видеонууд (одоо үзэж байгаагаасаа бусдыг харуулна)
  const recommendedVideos = videos.filter((v) => v.id !== id).slice(0, 8);

  // Видео олдохгүй бол
  if (!video) {
    return (
      <div className="flex-1 bg-[#0f0f0f] flex flex-col items-center justify-center min-h-screen">
        <div className="text-6xl mb-4">😔</div>
        <h2 className="text-white text-2xl font-bold mb-2">Видео олдсонгүй</h2>
        <p className="text-gray-400 mb-6">
          Уг видео устгагдсан эсвэл нийтлэгдээгүй байна.
        </p>
        <button
          onClick={() => navigate("/")}
          className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white rounded-full font-medium transition-colors"
        >
          Нүүр хуудас руу буцах
        </button>
      </div>
    );
  }

  // Таалагдлаа товч
  const handleLike = () => {
    setIsLiked(!isLiked);
    if (isDisliked) setIsDisliked(false);
  };

  // Таалагдсангүй товч
  const handleDislike = () => {
    setIsDisliked(!isDisliked);
    if (isLiked) setIsLiked(false);
  };

  // Сэтгэгдэл нэмэх
  const handleAddComment = () => {
    if (!commentText.trim()) return;
    const newComment = {
      id: `new-${Date.now()}`,
      author: "Та",
      avatar: "https://api.dicebear.com/7.x/initials/svg?seed=Та&backgroundColor=e53e3e",
      text: commentText.trim(),
      likes: 0,
      time: "Дөнгөж сая",
    };
    setComments([newComment, ...comments]);
    setCommentText("");
  };

  // Холбоос хуулах
  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="flex-1 bg-[#0f0f0f] min-h-screen">
      {/* ─── Буцах товч (mobile) ─── */}
      <div className="lg:hidden px-4 py-2 bg-[#0f0f0f]">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
        >
          <AiOutlineArrowLeft size={20} />
          <span className="text-sm">Буцах</span>
        </button>
      </div>

      <div className="max-w-screen-2xl mx-auto px-4 py-4">
        <div className="flex flex-col xl:flex-row gap-6">

          {/* ═══════════════════════════════
              ЗҮҮН ХЭСЭГ: Видео + Мэдээлэл
          ═══════════════════════════════ */}
          <div className="flex-1 min-w-0">

            {/* ─── Видео тоглуулагч ─── */}
            <div className="w-full aspect-video bg-black rounded-xl overflow-hidden shadow-2xl">
              <iframe
                src={`https://www.youtube.com/embed/LXb3EKWsInQ?autoplay=0&rel=0`}
                title={video.title}
                className="w-full h-full"
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              />
            </div>

            {/* ─── Видеоны гарчиг ─── */}
            <div className="mt-4">
              <h1 className="text-white text-xl font-bold leading-snug">
                {video.title}
              </h1>
            </div>

            {/* ─── Сувгийн мэдээлэл + Товчнууд ─── */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-4 mt-4">

              {/* Сувгийн аватар & нэр */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <img
                  src={video.channelAvatar}
                  alt={video.channelName}
                  className="w-10 h-10 rounded-full flex-shrink-0"
                />
                <div className="min-w-0">
                  <p className="text-white font-semibold text-sm truncate">
                    {video.channelName}
                  </p>
                  <p className="text-gray-400 text-xs">
                    {video.subscribers} дагагч
                  </p>
                </div>

                {/* Бүртгэл товч */}
                <button
                  onClick={() => setIsSubscribed(!isSubscribed)}
                  className={`flex items-center gap-2 ml-2 px-4 py-2 rounded-full text-sm font-semibold transition-all flex-shrink-0 ${
                    isSubscribed
                      ? "bg-gray-700 text-white hover:bg-gray-600"
                      : "bg-white text-black hover:bg-gray-200"
                  }`}
                >
                  {isSubscribed ? (
                    <>
                      <AiOutlineBell size={16} />
                      Бүртгэлтэй
                    </>
                  ) : (
                    "Бүртгүүлэх"
                  )}
                </button>
              </div>

              {/* ─── Үйлдлийн товчнууд ─── */}
              <div className="flex items-center gap-2 flex-wrap">

                {/* Таалагдлаа / Таалагдсангүй */}
                <div className="flex items-center bg-gray-800 hover:bg-gray-700 rounded-full overflow-hidden">
                  <button
                    onClick={handleLike}
                    className={`flex items-center gap-2 px-4 py-2 text-sm font-medium transition-colors border-r border-gray-600 ${
                      isLiked ? "text-blue-400" : "text-white"
                    }`}
                  >
                    {isLiked ? (
                      <LikeFilled size={18} className="fill-blue-400" />
                    ) : (
                      <AiOutlineLike size={18} />
                    )}
                    {video.likes}
                  </button>
                  <button
                    onClick={handleDislike}
                    className={`flex items-center px-3 py-2 text-sm transition-colors ${
                      isDisliked ? "text-red-400" : "text-white"
                    }`}
                  >
                    <AiOutlineDislike size={18} />
                  </button>
                </div>

                {/* Хуваалцах */}
                <button
                  onClick={() => setShowShareModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-full text-sm font-medium transition-colors"
                >
                  <AiOutlineShareAlt size={18} />
                  Хуваалцах
                </button>

                {/* Хадгалах */}
                <button
                  onClick={() => setShowSaveModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-full text-sm font-medium transition-colors"
                >
                  <MdOutlinePlaylistAdd size={18} />
                  Хадгалах
                </button>

                {/* Татаж авах */}
                <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-full text-sm font-medium transition-colors hidden sm:flex">
                  <AiOutlineDownload size={18} />
                  Татах
                </button>

                {/* Хэрчих */}
                <button className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-full text-sm font-medium transition-colors hidden lg:flex">
                  ✂️ Хэрчих
                </button>

                {/* Цэс */}
                <button className="p-2 bg-gray-800 hover:bg-gray-700 text-white rounded-full transition-colors">
                  <AiOutlineEllipsis size={20} />
                </button>
              </div>
            </div>

            {/* ─── Тайлбар хэсэг ─── */}
            <div className="mt-4 bg-gray-800/50 rounded-xl p-4">
              {/* Үзэлт & Огноо */}
              <div className="flex items-center gap-2 text-sm font-semibold text-white mb-2">
                <span>{video.views} үзэлт</span>
                <span className="text-gray-400">•</span>
                <span className="text-gray-400">{video.uploadedAt}</span>
                <span className="ml-auto px-2 py-0.5 bg-gray-700 text-gray-300 rounded text-xs">
                  #{video.category}
                </span>
              </div>

              {/* Тайлбарын текст */}
              <p
                className={`text-gray-300 text-sm leading-relaxed whitespace-pre-wrap ${
                  !showFullDesc ? "line-clamp-3" : ""
                }`}
              >
                {video.description}
              </p>

              {/* Дэлгэрэнгүй/Хаах товч */}
              <button
                onClick={() => setShowFullDesc(!showFullDesc)}
                className="mt-2 text-sm font-semibold text-white hover:text-gray-300 transition-colors"
              >
                {showFullDesc ? "Хаах ▲" : "Дэлгэрэнгүй ▼"}
              </button>
            </div>

            {/* ─── Сэтгэгдлийн хэсэг ─── */}
            <div className="mt-6">
              {/* Сэтгэгдлийн гарчиг */}
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white font-semibold text-base">
                  {comments.length} сэтгэгдэл
                </h3>
                <button className="flex items-center gap-2 text-gray-300 hover:text-white text-sm transition-colors">
                  <MdOutlineSort size={20} />
                  Эрэмбэлэх
                </button>
              </div>

              {/* Сэтгэгдэл бичих талбар */}
              <div className="flex items-start gap-3 mb-6">
                <img
                  src="https://api.dicebear.com/7.x/initials/svg?seed=Та&backgroundColor=e53e3e"
                  alt="Таны зураг"
                  className="w-9 h-9 rounded-full flex-shrink-0"
                />
                <div className="flex-1">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAddComment()}
                    placeholder="Сэтгэгдэл бичих..."
                    className="w-full bg-transparent border-b border-gray-600 focus:border-blue-500 text-white text-sm py-1 outline-none placeholder-gray-500 transition-colors"
                  />
                  {commentText && (
                    <div className="flex justify-end gap-2 mt-2">
                      <button
                        onClick={() => setCommentText("")}
                        className="px-4 py-1.5 text-sm text-gray-300 hover:text-white hover:bg-gray-700 rounded-full transition-colors"
                      >
                        Болих
                      </button>
                      <button
                        onClick={handleAddComment}
                        className="flex items-center gap-1 px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-full transition-colors"
                      >
                        <AiOutlineSend size={14} />
                        Нийтлэх
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Сэтгэгдлүүдийн жагсаалт */}
              <div className="space-y-5">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <img
                      src={comment.avatar}
                      alt={comment.author}
                      className="w-9 h-9 rounded-full flex-shrink-0"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-white text-sm font-semibold">
                          {comment.author}
                        </span>
                        <span className="text-gray-500 text-xs">
                          {comment.time}
                        </span>
                      </div>
                      <p className="text-gray-300 text-sm leading-relaxed">
                        {comment.text}
                      </p>
                      <div className="flex items-center gap-3 mt-2">
                        <button className="flex items-center gap-1 text-gray-400 hover:text-white text-xs transition-colors">
                          <AiOutlineLike size={14} />
                          {comment.likes > 0 && comment.likes}
                        </button>
                        <button className="flex items-center gap-1 text-gray-400 hover:text-white text-xs transition-colors">
                          <AiOutlineDislike size={14} />
                        </button>
                        <button className="text-gray-400 hover:text-white text-xs transition-colors">
                          Хариулах
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* ═══════════════════════════════
              БАРУУН ХЭСЭГ: Санал болгосон видео
          ═══════════════════════════════ */}
          <div className="xl:w-96 flex-shrink-0">
            <h3 className="text-white font-semibold mb-4 text-base">
              Санал болгосон бичлэгүүд
            </h3>
            <div className="space-y-3">
              {recommendedVideos.map((rec) => (
                <RecommendedCard key={rec.id} video={rec} />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ─── Хуваалцах Modal ─── */}
      {showShareModal && (
        <div
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
          onClick={() => setShowShareModal(false)}
        >
          <div
            className="bg-[#282828] rounded-2xl p-6 w-full max-w-md shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-white text-lg font-semibold mb-4">
              Хуваалцах
            </h3>
            <div className="flex gap-3 mb-4">
              {/* Нийгмийн сүлжээнүүд */}
              {[
                { label: "Facebook", emoji: "📘", color: "bg-blue-600" },
                { label: "Twitter", emoji: "🐦", color: "bg-sky-500" },
                { label: "WhatsApp", emoji: "💬", color: "bg-green-600" },
                { label: "Telegram", emoji: "✈️", color: "bg-blue-500" },
              ].map((s) => (
                <button
                  key={s.label}
                  className={`flex flex-col items-center gap-1 flex-1 py-3 ${s.color} rounded-xl text-white text-xs font-medium hover:opacity-90 transition-opacity`}
                >
                  <span className="text-2xl">{s.emoji}</span>
                  {s.label}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 bg-gray-700 rounded-xl px-3 py-2">
              <span className="text-gray-300 text-xs flex-1 truncate">
                {window.location.href}
              </span>
              <button
                onClick={handleCopyLink}
                className="flex-shrink-0 px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs rounded-lg transition-colors font-medium"
              >
                {copiedLink ? "✓ Хуулагдлаа" : "Хуулах"}
              </button>
            </div>
            <button
              onClick={() => setShowShareModal(false)}
              className="mt-4 w-full py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-xl text-sm transition-colors"
            >
              Хаах
            </button>
          </div>
        </div>
      )}

      {/* ─── Хадгалах Modal ─── */}
      {showSaveModal && (
        <div
          className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4"
          onClick={() => setShowSaveModal(false)}
        >
          <div
            className="bg-[#282828] rounded-2xl p-6 w-full max-w-sm shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-white text-lg font-semibold mb-4">
              Жагсаалтад хадгалах
            </h3>
            <div className="space-y-2">
              {["Дараа үзэх", "Таалагдсан видео", "Миний эмхэтгэл"].map(
                (list) => (
                  <label
                    key={list}
                    className="flex items-center gap-3 p-3 hover:bg-gray-700 rounded-xl cursor-pointer transition-colors"
                  >
                    <input
                      type="checkbox"
                      className="w-4 h-4 accent-blue-500"
                    />
                    <span className="text-white text-sm">{list}</span>
                  </label>
                )
              )}
            </div>
            <button
              onClick={() => setShowSaveModal(false)}
              className="mt-4 w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-medium transition-colors"
            >
              Хадгалах
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// ─── Санал болгосон видеоны жижиг карт ─────────────────
interface RecommendedCardProps {
  video: {
    id: string;
    title: string;
    channelName: string;
    thumbnail: string;
    views: string;
    uploadedAt: string;
    duration: string;
    channelAvatar: string;
  };
}

const RecommendedCard = ({ video }: RecommendedCardProps) => {
  const navigate = useNavigate();
  const [imgErr, setImgErr] = useState(false);

  return (
    <div
      className="flex gap-2 cursor-pointer group"
      onClick={() => navigate(`/video/${video.id}`)}
    >
      {/* Thumbnail */}
      <div className="relative flex-shrink-0 w-40 aspect-video bg-gray-800 rounded-lg overflow-hidden">
        {!imgErr ? (
          <img
            src={video.thumbnail}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={() => setImgErr(true)}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
            <span className="text-2xl">🎬</span>
          </div>
        )}
        <div className="absolute bottom-1 right-1 bg-black/80 text-white text-[10px] px-1 py-0.5 rounded font-medium">
          {video.duration}
        </div>
      </div>

      {/* Мэдээлэл */}
      <div className="flex-1 min-w-0">
        <h4 className="text-white text-xs font-semibold leading-snug line-clamp-2 group-hover:text-gray-200">
          {video.title}
        </h4>
        <p className="text-gray-400 text-xs mt-1 truncate">{video.channelName}</p>
        <p className="text-gray-500 text-xs">
          {video.views} • {video.uploadedAt}
        </p>
      </div>
    </div>
  );
};

export default VideoPlayerPage;
