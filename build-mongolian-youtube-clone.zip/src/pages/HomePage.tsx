// ============================
// АЛХАМ 4: Нүүр хуудас
// ============================

import { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { AiOutlineSearch } from "react-icons/ai";
import VideoCard from "../components/VideoCard";
import CategoryFilter from "../components/CategoryFilter";
import { videos, categories } from "../data/videos";

const HomePage = () => {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get("search") || "";

  // Хайлт ба ангилалаар шүүх
  const filteredVideos = useMemo(() => {
    let result = videos;

    // Хайлтаар шүүх
    if (searchQuery) {
      result = result.filter(
        (v) =>
          v.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.channelName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Ангилалаар шүүх
    if (activeCategory !== "all") {
      result = result.filter((v) => v.category === activeCategory);
    }

    return result;
  }, [activeCategory, searchQuery]);

  return (
    <div className="flex-1 bg-[#0f0f0f] min-h-screen">
      {/* ─── Ангилал шүүгч ─── */}
      <div className="sticky top-14 z-20 bg-[#0f0f0f] px-4 border-b border-gray-800">
        <CategoryFilter
          categories={categories}
          activeCategory={activeCategory}
          onCategoryChange={setActiveCategory}
        />
      </div>

      {/* ─── Хайлтын үр дүнгийн гарчиг ─── */}
      {searchQuery && (
        <div className="px-6 pt-4 pb-2">
          <h2 className="text-white text-lg font-semibold flex items-center gap-2">
            <AiOutlineSearch className="text-gray-400" />
            <span className="text-gray-400">«</span>
            <span className="text-red-400">{searchQuery}</span>
            <span className="text-gray-400">»</span>
            <span className="text-gray-400 text-base font-normal">
              — {filteredVideos.length} үр дүн
            </span>
          </h2>
        </div>
      )}

      {/* ─── Видео жагсаалт ─── */}
      <div className="px-4 py-4">
        {filteredVideos.length > 0 ? (
          <div
            className="grid gap-x-4 gap-y-8"
            style={{
              gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
            }}
          >
            {filteredVideos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        ) : (
          // Хайлтын үр дүн олдоогүй
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-white text-xl font-semibold mb-2">
              Үр дүн олдсонгүй
            </h3>
            <p className="text-gray-400 text-sm max-w-sm">
              «{searchQuery || activeCategory}» хайлтад тохирох видео олдсонгүй.
              Өөр үгс ашиглаж хайж үзнэ үү.
            </p>
            <button
              onClick={() => {
                setActiveCategory("all");
                window.history.pushState({}, "", "/");
                window.location.reload();
              }}
              className="mt-4 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-full text-sm transition-colors"
            >
              Бүгдийг харах
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default HomePage;
