// ================================================
// АЛХАМ 2: Монгол хэл дээрх жишээ өгөгдлүүд
// ================================================

import { Video, Category } from "../types";

export const videos: Video[] = [
  // ─── Монгол Байгаль ───
  {
    id: "1",
    title: "Монгол нутгийн гайхамшигт байгаль - 4K дүрс бичлэг",
    channelName: "Монгол Байгаль ТВ",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МБ&backgroundColor=e53e3e",
    thumbnail: "https://picsum.photos/seed/mongolia1/640/360",
    views: "1.2М",
    uploadedAt: "3 өдрийн өмнө",
    duration: "12:45",
    description:
      "Монгол орны гайхамшигт байгалийг 4K чанартай дүрс бичлэгээр үзээрэй. Алтай, Хангай, Хэнтийн нуруу болон Говийн цөлийг нэг видеонд багтаасан боловсрол, аялал жуулчлалын зориулалттай бичлэг. Монгол байгальд дурлагсдад зориулав.",
    likes: "24К",
    category: "Байгаль",
    subscribers: "245К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c1",
        author: "Баяр Мөнхбат",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=БМ&backgroundColor=3182ce",
        text: "Үнэхээр гайхалтай байгаль! Монгол орондоо бахархдаг 🇲🇳",
        likes: 342,
        time: "1 өдрийн өмнө",
      },
      {
        id: "c2",
        author: "Нарантуяа Галбаатар",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=НГ&backgroundColor=38a169",
        text: "Ямар сайхан вэ! Энэ газруудаар аялахыг хүсч байна.",
        likes: 187,
        time: "2 өдрийн өмнө",
      },
      {
        id: "c3",
        author: "Төгөлдөр Энхбаяр",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ТЭ&backgroundColor=d69e2e",
        text: "4K чанар маш гоё гарчээ. Камер юу ашигласан бэ?",
        likes: 95,
        time: "3 өдрийн өмнө",
      },
    ],
  },

  // ─── Хоол ───
  {
    id: "2",
    title: "Монгол гурилтай хоол хийх арга - Цуйван, Банш, Бууз",
    channelName: "Монгол Гал Тогоо",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МГ&backgroundColor=d69e2e",
    thumbnail: "https://picsum.photos/seed/food1/640/360",
    views: "856К",
    uploadedAt: "1 долоо хоногийн өмнө",
    duration: "18:30",
    description:
      "Монголын уламжлалт гурилтай хоолнуудыг хэрхэн хийхийг алхам алхмаар заана. Цуйван, банш, бууз гурван хоолны жор болон нарийн нюансуудыг мэргэжлийн тогооч тайлбарлана.",
    likes: "15К",
    category: "Хоол хийх",
    subscribers: "128К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c4",
        author: "Сарнай Дорж",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=СД&backgroundColor=e53e3e",
        text: "Банш хийх заль арга маш сайн тайлбарласан байна. Баярлалаа!",
        likes: 521,
        time: "5 өдрийн өмнө",
      },
      {
        id: "c5",
        author: "Мөнхбаяр Цэрэн",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=МЦ&backgroundColor=805ad5",
        text: "Бууз дээр гурил хэр нимгэн дэлгэх вэ? Тодруулж өгнө үү.",
        likes: 234,
        time: "6 өдрийн өмнө",
      },
    ],
  },

  // ─── Технологи ───
  {
    id: "3",
    title: "React.js сурах бүрэн гарын авлага монгол хэлээр - 2024",
    channelName: "Кодер Монгол",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=КМ&backgroundColor=3182ce",
    thumbnail: "https://picsum.photos/seed/tech1/640/360",
    views: "423К",
    uploadedAt: "2 долоо хоногийн өмнө",
    duration: "1:24:15",
    description:
      "React.js-ийг эхнээс нь сурах бүрэн гарын авлага. Компонент, хукс, state management, routing зэргийг монгол хэлээр ойлгомжтой тайлбарласан. Програмчлалын туршлагагүй хүмүүст ч тохиромжтой.",
    likes: "8.2К",
    category: "Технологи",
    subscribers: "67К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c6",
        author: "Анхбаяр Лхагва",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=АЛ&backgroundColor=38a169",
        text: "Маш сайн тайлбарласан байна! Монгол хэлээр ийм агуулга хайж байлаа.",
        likes: 876,
        time: "1 долоо хоногийн өмнө",
      },
      {
        id: "c7",
        author: "Золзаяа Батжаргал",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ЗБ&backgroundColor=e53e3e",
        text: "hooks хэсгийг ойлгоход хэцүү байсан. Ийм тодорхой тайлбарласанд баярлалаа.",
        likes: 432,
        time: "2 долоо хоногийн өмнө",
      },
    ],
  },

  // ─── Спорт ───
  {
    id: "4",
    title: "Монголын Сүмо бөх - Улаанбаатар наадмын онцлох мөчүүд 2024",
    channelName: "Монгол Спорт Медиа",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МС&backgroundColor=dd6b20",
    thumbnail: "https://picsum.photos/seed/sport1/640/360",
    views: "2.1М",
    uploadedAt: "5 өдрийн өмнө",
    duration: "22:10",
    description:
      "2024 оны Наадмын бөхийн барилдааны шилдэг мөчүүд. Монголын Аварга тодруулах тэмцээний сонирхолтой хэсгүүдийг нэг видеонд цуглуулав.",
    likes: "45К",
    category: "Спорт",
    subscribers: "512К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c8",
        author: "Батболд Сүхбаатар",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=БС&backgroundColor=3182ce",
        text: "Монголын бөх дэлхийд хамгийн шилдэг! 💪",
        likes: 1243,
        time: "4 өдрийн өмнө",
      },
      {
        id: "c9",
        author: "Уянга Пүрэвсүрэн",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=УП&backgroundColor=38a169",
        text: "Хаан аварга гайхалтай байсан шүү. Дараагийн жил ч аварга болно гэж найдаж байна.",
        likes: 876,
        time: "4 өдрийн өмнө",
      },
    ],
  },

  // ─── Хөгжим ───
  {
    id: "5",
    title: "Монгол ардын дуу - Морин хуурын аялгуу 🎵 Тайвшруулах хөгжим",
    channelName: "Морин Хуур Студи",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МХ&backgroundColor=805ad5",
    thumbnail: "https://picsum.photos/seed/music1/640/360",
    views: "678К",
    uploadedAt: "2 сарын өмнө",
    duration: "45:00",
    description:
      "Монголын уламжлалт морин хуурын тайвшруулах аялгуунуудын цуглуулга. Унтах, суралцах, ажиллах үедээ сонсоход тохиромжтой. Уртын дуу болон богино дуунуудыг оруулсан.",
    likes: "32К",
    category: "Хөгжим",
    subscribers: "189К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c10",
        author: "Нандинцэцэг Балдан",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=НБ&backgroundColor=e53e3e",
        text: "Морин хуурын аялгуу сонсохоор сэтгэл тайвшрах юм. Гайхалтай!",
        likes: 2341,
        time: "1 сарын өмнө",
      },
    ],
  },

  // ─── Аялал ───
  {
    id: "6",
    title: "Говийн цөлөөр аялал - Хонгорын элс, Баянзаг хавцал",
    channelName: "Монгол Аялагч",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МА&backgroundColor=d69e2e",
    thumbnail: "https://picsum.photos/seed/travel1/640/360",
    views: "934К",
    uploadedAt: "3 долоо хоногийн өмнө",
    duration: "28:55",
    description:
      "Говийн цөлийн гайхамшигт газруудаар аяллын бичлэг. Хонгорын элс, Баянзаг хавцал, Цагаан суварга зэрэг газруудаар аялж, аялалын зардал, хугацаа, зөвлөмжүүдийг хуваалцана.",
    likes: "18К",
    category: "Аялал",
    subscribers: "321К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c11",
        author: "Эрдэнэбат Жаргал",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ЭЖ&backgroundColor=3182ce",
        text: "Говь очмоор байна! Хэдэн хоног аяллаа?",
        likes: 654,
        time: "2 долоо хоногийн өмнө",
      },
      {
        id: "c12",
        author: "Солонго Дамдинсүрэн",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=СД2&backgroundColor=805ad5",
        text: "Жолоодож очих боломжтой юу? Аялалын компани ашиглах шаардлагатай юу?",
        likes: 321,
        time: "2 долоо хоногийн өмнө",
      },
    ],
  },

  // ─── Боловсрол ───
  {
    id: "7",
    title: "Монгол хэлний дүрэм - 8-р ангийн хичээл | Бүрэн тайлбар",
    channelName: "Боловсрол Монгол",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=БОЛ&backgroundColor=38a169",
    thumbnail: "https://picsum.photos/seed/edu1/640/360",
    views: "312К",
    uploadedAt: "1 сарын өмнө",
    duration: "35:20",
    description:
      "8-р ангийн монгол хэлний дүрмийг бүрэн тайлбарлах хичээл. ЭЕШ болон бусад шалгалтад бэлдэж буй сурагчдад тусална. Өгүүлбэр зүй, үгсийн сан, дүрмийн дасгалуудыг хамтад нь орсон.",
    likes: "9.5К",
    category: "Боловсрол",
    subscribers: "445К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c13",
        author: "Цэцэгмаа Пүрэв",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ЦП&backgroundColor=d69e2e",
        text: "ЭЕШ-д бэлдэж буй хүүхдүүдэд маш хэрэгтэй. Баярлалаа багш аа!",
        likes: 1876,
        time: "3 долоо хоногийн өмнө",
      },
    ],
  },

  // ─── Технологи ───
  {
    id: "8",
    title: "Artificial Intelligence (AI) ирээдүй - Монгол хэлний тайлбар",
    channelName: "Тех Монгол",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=ТМ&backgroundColor=3182ce",
    thumbnail: "https://picsum.photos/seed/ai1/640/360",
    views: "567К",
    uploadedAt: "4 өдрийн өмнө",
    duration: "16:40",
    description:
      "Хиймэл оюун ухаан (AI) гэж юу болох, ирээдүйд хэрхэн нөлөөлөх талаар монгол хэлээр тайлбарлана. ChatGPT, Gemini, Midjourney зэрэг хэрэглүүрүүдийг ашиглах заавар.",
    likes: "12К",
    category: "Технологи",
    subscribers: "89К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c14",
        author: "Ганбаатар Цэрэндорж",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ГЦ&backgroundColor=805ad5",
        text: "AI ирээдүйн технологи. Монголд ч гэсэн хурдан хөгжинө гэж найдаж байна.",
        likes: 543,
        time: "3 өдрийн өмнө",
      },
    ],
  },

  // ─── Хоол ───
  {
    id: "9",
    title: "Монгол шөлтэй хоолнууд - Өвлийн 5 дулаан хоол",
    channelName: "Монгол Гал Тогоо",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МГ&backgroundColor=d69e2e",
    thumbnail: "https://picsum.photos/seed/food2/640/360",
    views: "445К",
    uploadedAt: "2 долоо хоногийн өмнө",
    duration: "20:15",
    description:
      "Өвлийн хүйтэнд дулаацуулах монгол уламжлалт шөлтэй 5 хоолны жор. Гурилтай шөл, цагаан идээтэй шөл, хоньны шөл зэрэг амттай хоолнуудыг гэртээ хийж үзээрэй.",
    likes: "11К",
    category: "Хоол хийх",
    subscribers: "128К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c15",
        author: "Амармандах Гэрэлт",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=АГ&backgroundColor=dd6b20",
        text: "Гурилтай шөл ямар амттай болдог юм бэ! Заавал хийж үзнэ.",
        likes: 765,
        time: "1 долоо хоногийн өмнө",
      },
    ],
  },

  // ─── Кино/Урлаг ───
  {
    id: "10",
    title: "Монгол кино шүүмж - 'Нохой' киноны задлал ба дүн шинжилгээ",
    channelName: "Кино Шүүмж МН",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=КШ&backgroundColor=e53e3e",
    thumbnail: "https://picsum.photos/seed/movie1/640/360",
    views: "289К",
    uploadedAt: "6 өдрийн өмнө",
    duration: "14:30",
    description:
      "Монголын алдарт 'Нохой' киноны дүн шинжилгээ, нарийн утга санааг задалж тайлбарлана. Монгол кино урлагийн хөгжил, тухайн кино дэлхийд хэрхэн хүлээж авагдсан талаар ярилцана.",
    likes: "7.8К",
    category: "Кино",
    subscribers: "156К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c16",
        author: "Мөнхзул Батбаяр",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=МБ2&backgroundColor=3182ce",
        text: "Монгол кино дэлхийн түвшинд хүрч байна. Бахархмаар!",
        likes: 432,
        time: "5 өдрийн өмнө",
      },
    ],
  },

  // ─── Эрүүл мэнд ───
  {
    id: "11",
    title: "Өглөөний дасгал хөдөлгөөн - 15 минутын бүрэн дасгал",
    channelName: "Эрүүл Монгол",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=ЭМ&backgroundColor=38a169",
    thumbnail: "https://picsum.photos/seed/fitness1/640/360",
    views: "1.5М",
    uploadedAt: "1 сарын өмнө",
    duration: "15:00",
    description:
      "Өглөө бүр хийх 15 минутын дасгал хөдөлгөөний бүрэн гарын авлага. Тусгай тоног хэрэгсэл шаардлагагүй. Гэртээ хийх боломжтой бүх насны хүмүүст тохиромжтой дасгалууд.",
    likes: "28К",
    category: "Эрүүл мэнд",
    subscribers: "234К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c17",
        author: "Оюунтуяа Хишигт",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ОХ&backgroundColor=805ad5",
        text: "7 хоног дараалан хийлээ. Биеийн хөнгөн мэдрэгдэж байна!",
        likes: 3421,
        time: "2 долоо хоногийн өмнө",
      },
    ],
  },

  // ─── Байгаль ───
  {
    id: "12",
    title: "Хөвсгөл нуур - Монголын далай | Аялалын гарын авлага",
    channelName: "Монгол Аялагч",
    channelAvatar: "https://api.dicebear.com/7.x/initials/svg?seed=МА&backgroundColor=d69e2e",
    thumbnail: "https://picsum.photos/seed/lake1/640/360",
    views: "756К",
    uploadedAt: "1 сарын өмнө",
    duration: "32:20",
    description:
      "Хөвсгөл нуурт аялах бүрэн гарын авлага. Хэрхэн очих, хаана буух, юу идэх, ямар үйл ажиллагаа хийх талаар дэлгэрэнгүй мэдээлэл. Нуурын гайхалтай байгалийг 4K видеогоор үзнэ үү.",
    likes: "22К",
    category: "Байгаль",
    subscribers: "321К",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    comments: [
      {
        id: "c18",
        author: "Тэмүүлэн Батсүх",
        avatar: "https://api.dicebear.com/7.x/initials/svg?seed=ТБ&backgroundColor=dd6b20",
        text: "Хөвсгөл бол монголын нандин эрдэнэ шүү. Заавал очих газар!",
        likes: 1876,
        time: "3 долоо хоногийн өмнө",
      },
    ],
  },
];

// ─── Ангилалууд ───
export const categories: Category[] = [
  { id: "all", label: "Бүгд" },
  { id: "Байгаль", label: "🏔️ Байгаль" },
  { id: "Хоол хийх", label: "🍲 Хоол хийх" },
  { id: "Технологи", label: "💻 Технологи" },
  { id: "Спорт", label: "🏅 Спорт" },
  { id: "Хөгжим", label: "🎵 Хөгжим" },
  { id: "Аялал", label: "✈️ Аялал" },
  { id: "Боловсрол", label: "📚 Боловсрол" },
  { id: "Кино", label: "🎬 Кино" },
  { id: "Эрүүл мэнд", label: "💪 Эрүүл мэнд" },
];
