// ================================
// АЛХАМ 4: Ангилал шүүгчийн компонент
// ================================

import { useRef } from "react";
import { AiOutlineLeft, AiOutlineRight } from "react-icons/ai";
import { Category } from "../types";

interface CategoryFilterProps {
  categories: Category[];
  activeCategory: string;
  onCategoryChange: (id: string) => void;
}

const CategoryFilter = ({
  categories,
  activeCategory,
  onCategoryChange,
}: CategoryFilterProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Зүүн гүйлгэх
  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -200, behavior: "smooth" });
    }
  };

  // Баруун гүйлгэх
  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 200, behavior: "smooth" });
    }
  };

  return (
    <div className="relative flex items-center bg-[#0f0f0f] py-3">
      {/* Зүүн сум */}
      <button
        onClick={scrollLeft}
        className="flex-shrink-0 p-1 mr-1 bg-[#0f0f0f] hover:bg-gray-700 rounded-full text-white transition-colors z-10"
      >
        <AiOutlineLeft size={16} />
      </button>

      {/* Ангилалын жагсаалт */}
      <div
        ref={scrollRef}
        className="flex gap-2 overflow-x-auto scrollbar-hide flex-1"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onCategoryChange(cat.id)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
              activeCategory === cat.id
                ? "bg-white text-black"
                : "bg-gray-700 text-white hover:bg-gray-600"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Баруун сум */}
      <button
        onClick={scrollRight}
        className="flex-shrink-0 p-1 ml-1 bg-[#0f0f0f] hover:bg-gray-700 rounded-full text-white transition-colors z-10"
      >
        <AiOutlineRight size={16} />
      </button>
    </div>
  );
};

export default CategoryFilter;
