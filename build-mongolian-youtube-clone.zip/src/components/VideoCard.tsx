// ============================
// АЛХАМ 4: VideoCard компонент
// ============================

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AiOutlineEllipsis, AiOutlineClockCircle } from "react-icons/ai";
import { MdOutlineWatchLater, MdOutlinePlaylistAdd } from "react-icons/md";
import { Video } from "../types";

interface VideoCardProps {
  video: Video;
}

const VideoCard = ({ video }: VideoCardProps) => {
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);
  const [imgError, setImgError] = useState(false);

  const handleClick = () => {
    navigate(`/video/${video.id}`);
  };

  return (
    <div className="group cursor-pointer">
      {/* ─── Thumbnail хэсэг ─── */}
      <div
        className="relative w-full aspect-video bg-gray-800 rounded-xl overflow-hidden mb-3"
        onClick={handleClick}
      >
        {/* Thumbnail зураг */}
        {!imgError ? (
          <img
            src={video.thumbnail}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            onError={() => setImgError(true)}
            loading="lazy"
          />
        ) : (
          // Зураг ачаалагдахгүй бол placeholder
          <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
            <span className="text-4xl">🎬</span>
          </div>
        )}

        {/* Видеоны хугацаа */}
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
          {video.duration}
        </div>

        {/* Hover-д харагдах тоглуулах товч */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="bg-black/60 rounded-full p-3">
            <svg viewBox="0 0 24 24" fill="white" className="w-8 h-8">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>

        {/* Дараа үзэх - hover-д харагдана */}
        <button
          className="absolute top-2 right-2 bg-black/80 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black"
          onClick={(e) => {
            e.stopPropagation();
          }}
          title="Дараа үзэх"
        >
          <AiOutlineClockCircle size={16} />
        </button>
      </div>

      {/* ─── Мэдээллийн хэсэг ─── */}
      <div className="flex gap-3">
        {/* Сувгийн аватар */}
        <div className="flex-shrink-0 mt-0.5" onClick={handleClick}>
          <img
            src={video.channelAvatar}
            alt={video.channelName}
            className="w-9 h-9 rounded-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                `https://api.dicebear.com/7.x/initials/svg?seed=${video.channelName}`;
            }}
          />
        </div>

        {/* Гарчиг, мэдээлэл */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-1">
            {/* Гарчиг */}
            <h3
              className="text-white text-sm font-semibold leading-snug line-clamp-2 flex-1 hover:text-gray-200 cursor-pointer"
              onClick={handleClick}
            >
              {video.title}
            </h3>

            {/* Цэс товч */}
            <div className="relative flex-shrink-0">
              <button
                className="p-1 rounded-full hover:bg-gray-700 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMenu(!showMenu);
                }}
              >
                <AiOutlineEllipsis size={20} />
              </button>

              {/* Унждаг цэс */}
              {showMenu && (
                <div className="absolute right-0 top-8 bg-[#282828] rounded-xl shadow-2xl py-2 w-52 z-20 border border-gray-700">
                  <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-200 hover:bg-gray-700 transition-colors">
                    <MdOutlineWatchLater size={18} />
                    Дараа үзэх
                  </button>
                  <button className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-gray-200 hover:bg-gray-700 transition-colors">
                    <MdOutlinePlaylistAdd size={18} />
                    Жагсаалтад нэмэх
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Сувгийн нэр */}
          <p className="text-gray-400 text-sm mt-1 hover:text-gray-200 cursor-pointer truncate">
            {video.channelName}
          </p>

          {/* Үзэлт & Хугацаа */}
          <p className="text-gray-400 text-xs mt-0.5">
            {video.views} үзэлт &nbsp;•&nbsp; {video.uploadedAt}
          </p>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;
