// ========================
// АЛХАМ 3: Sidebar компонент
// ========================

import { useNavigate, useLocation } from "react-router-dom";
import {
  AiOutlineHome,
  AiOutlineHistory,
  AiOutlineLike,
  AiOutlineClockCircle,
  AiOutlineFire,
  AiOutlineSetting,
  AiOutlineQuestionCircle,
  AiOutlineFlag,
} from "react-icons/ai";
import {
  MdOutlineSubscriptions,
  MdOutlineVideoLibrary,
  MdOutlineSportsHandball,
  MdOutlineMusicNote,
  MdOutlineMovie,
  MdOutlineLightbulb,
} from "react-icons/md";
import { PiVideoFill } from "react-icons/pi";
import { HiOutlineUserGroup } from "react-icons/hi2";

interface SidebarProps {
  isOpen: boolean;
}

// Цэсний нэг мөрийн компонент
interface MenuItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
  badge?: string;
}

const MenuItem = ({ icon, label, active, onClick, badge }: MenuItemProps) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-3 py-2 rounded-xl text-sm font-medium transition-all group ${
      active
        ? "bg-gray-700 text-white"
        : "text-gray-300 hover:bg-gray-700/60 hover:text-white"
    }`}
  >
    <span className={`text-xl flex-shrink-0 ${active ? "text-white" : "text-gray-400 group-hover:text-white"}`}>
      {icon}
    </span>
    <span className="truncate">{label}</span>
    {badge && (
      <span className="ml-auto bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
        {badge}
      </span>
    )}
  </button>
);

// Хэсгийн гарчиг
const SectionTitle = ({ title }: { title: string }) => (
  <p className="px-3 py-1 text-xs font-semibold text-gray-500 uppercase tracking-wider mt-2">
    {title}
  </p>
);

// Хэсгийг хуваах зураас
const Divider = () => <div className="my-2 border-t border-gray-700/50" />;

const Sidebar = ({ isOpen }: SidebarProps) => {
  const navigate = useNavigate();
  const location = useLocation();

  const isHome = location.pathname === "/";

  return (
    <>
      {/* ─── Арын бүрхэвч (mobile) ─── */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => {}}
        />
      )}

      {/* ─── Sidebar үндсэн хэсэг ─── */}
      <aside
        className={`fixed top-14 left-0 h-[calc(100vh-56px)] z-40 bg-[#0f0f0f] overflow-y-auto transition-all duration-300 ease-in-out scrollbar-hide
        ${isOpen ? "w-60 translate-x-0" : "w-0 -translate-x-full lg:w-60 lg:translate-x-0"}
        `}
        style={{ scrollbarWidth: "none" }}
      >
        <div className="px-2 py-2 space-y-0.5">

          {/* ─── Үндсэн цэс ─── */}
          <MenuItem
            icon={<AiOutlineHome />}
            label="Нүүр"
            active={isHome}
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<PiVideoFill />}
            label="Богино бичлэг"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<MdOutlineSubscriptions />}
            label="Бүртгэлүүд"
            badge="12"
            onClick={() => navigate("/")}
          />

          <Divider />

          {/* ─── Та ─── */}
          <SectionTitle title="Та" />
          <MenuItem
            icon={<MdOutlineVideoLibrary />}
            label="Таны сан"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<AiOutlineHistory />}
            label="Үзэлтийн түүх"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<AiOutlineClockCircle />}
            label="Дараа үзэх"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<AiOutlineLike />}
            label="Таалагдсан видео"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<HiOutlineUserGroup />}
            label="Миний суваг"
            onClick={() => navigate("/")}
          />

          <Divider />

          {/* ─── Шилдэг ─── */}
          <SectionTitle title="Шилдэг" />
          <MenuItem
            icon={<AiOutlineFire />}
            label="Эрэлттэй"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<MdOutlineMusicNote />}
            label="Хөгжим"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<MdOutlineSportsHandball />}
            label="Спорт"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<MdOutlineMovie />}
            label="Кино"
            onClick={() => navigate("/")}
          />
          <MenuItem
            icon={<MdOutlineLightbulb />}
            label="Сурах"
            onClick={() => navigate("/")}
          />

          <Divider />

          {/* ─── Тусламж & Тохиргоо ─── */}
          <SectionTitle title="Тусламж" />
          <MenuItem
            icon={<AiOutlineSetting />}
            label="Тохиргоо"
            onClick={() => {}}
          />
          <MenuItem
            icon={<AiOutlineFlag />}
            label="Санал хүргүүлэх"
            onClick={() => {}}
          />
          <MenuItem
            icon={<AiOutlineQuestionCircle />}
            label="Тусламж"
            onClick={() => {}}
          />

          {/* ─── Хуулийн мэдэгдэл ─── */}
          <Divider />
          <div className="px-3 py-2">
            <p className="text-[11px] text-gray-600 leading-relaxed">
              © 2024 МонТьюб ХХК
              <br />
              Монгол Улс • Нууцлалын бодлого
              <br />
              Үйлчилгээний нөхцөл
            </p>
          </div>

        </div>
      </aside>
    </>
  );
};

export default Sidebar;
