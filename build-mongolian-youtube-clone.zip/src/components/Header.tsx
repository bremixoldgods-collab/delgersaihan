// ========================
// АЛХАМ 3: Header компонент
// ========================

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  AiOutlineSearch,
  AiOutlineBell,
  AiOutlineVideoCamera,
  AiOutlineMenu,
  AiOutlineClose,
} from "react-icons/ai";
import { MdOutlineAccountCircle } from "react-icons/md";
import { HiMicrophone } from "react-icons/hi2";

interface HeaderProps {
  onMenuToggle: () => void;
  isSidebarOpen: boolean;
}

const Header = ({ onMenuToggle, isSidebarOpen }: HeaderProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const navigate = useNavigate();

  // Хайлт хийх функц
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#0f0f0f] flex items-center justify-between px-4 h-14 gap-2">
      
      {/* ─── Зүүн хэсэг: Лого ─── */}
      <div className="flex items-center gap-4 flex-shrink-0">
        {/* Хажуугийн цэс нээх/хаах товч */}
        <button
          onClick={onMenuToggle}
          className="p-2 rounded-full hover:bg-gray-700 transition-colors text-white"
          aria-label="Цэс нээх"
        >
          {isSidebarOpen ? (
            <AiOutlineClose size={22} />
          ) : (
            <AiOutlineMenu size={22} />
          )}
        </button>

        {/* МонТьюб Лого */}
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-1 group"
        >
          {/* YouTube маягийн лого */}
          <div className="bg-red-600 rounded-lg px-2 py-1 flex items-center justify-center">
            <svg
              viewBox="0 0 24 24"
              fill="white"
              className="w-5 h-5"
            >
              <path d="M23 7s-.3-2-1.2-2.8c-1.1-1.2-2.4-1.2-3-1.3C16.1 2.7 12 2.7 12 2.7s-4.1 0-6.8.2C4.6 3 3.3 3 2.2 4.2 1.3 5 1 7 1 7S.7 9.3.7 11.5v2.1c0 2.2.3 4.4.3 4.4s.3 2 1.2 2.8c1.1 1.2 2.6 1.1 3.3 1.2C7.3 22.2 12 22.2 12 22.2s4.1 0 6.8-.2c.6-.1 1.9-.1 3-1.3.9-.8 1.2-2.8 1.2-2.8s.3-2.2.3-4.4v-2.1C23.3 9.3 23 7 23 7zM9.7 15.5V8.4l8.1 3.6-8.1 3.5z" />
            </svg>
          </div>
          <span className="text-white font-bold text-lg ml-1 hidden sm:block">
            Мон<span className="text-red-500">Тьюб</span>
          </span>
        </button>
      </div>

      {/* ─── Дунд хэсэг: Хайлт ─── */}
      <div className="flex items-center flex-1 max-w-2xl mx-2">
        <form
          onSubmit={handleSearch}
          className="flex flex-1 items-center"
        >
          {/* Хайлтын input */}
          <div
            className={`flex flex-1 items-center border rounded-l-full overflow-hidden transition-all ${
              isSearchFocused
                ? "border-blue-500 bg-[#121212]"
                : "border-gray-600 bg-[#121212]"
            }`}
          >
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setIsSearchFocused(false)}
              placeholder="Хайх..."
              className="flex-1 bg-transparent text-white text-sm px-4 py-2 outline-none placeholder-gray-500 min-w-0"
            />
          </div>

          {/* Хайх товч */}
          <button
            type="submit"
            className="px-5 py-2 bg-[#222222] hover:bg-[#3a3a3a] border border-gray-600 border-l-0 rounded-r-full text-gray-300 transition-colors"
            aria-label="Хайх"
          >
            <AiOutlineSearch size={20} />
          </button>
        </form>

        {/* Микрофон товч */}
        <button className="ml-2 p-2 bg-[#222222] hover:bg-gray-600 rounded-full text-white transition-colors flex-shrink-0 hidden sm:flex">
          <HiMicrophone size={18} />
        </button>
      </div>

      {/* ─── Баруун хэсэг: Хэрэгслүүд & Нэвтрэх ─── */}
      <div className="flex items-center gap-2 flex-shrink-0">
        {/* Видео байршуулах */}
        <button
          className="p-2 hover:bg-gray-700 rounded-full text-white transition-colors hidden md:flex"
          title="Видео байршуулах"
        >
          <AiOutlineVideoCamera size={22} />
        </button>

        {/* Мэдэгдэл */}
        <button
          className="p-2 hover:bg-gray-700 rounded-full text-white transition-colors relative hidden md:flex"
          title="Мэдэгдэл"
        >
          <AiOutlineBell size={22} />
          {/* Мэдэгдлийн тоо */}
          <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
            3
          </span>
        </button>

        {/* Нэвтрэх товч */}
        <button className="flex items-center gap-2 px-3 py-1.5 border border-blue-500 rounded-full text-blue-400 hover:bg-blue-500/10 transition-colors text-sm font-medium">
          <MdOutlineAccountCircle size={20} />
          <span className="hidden sm:block">Нэвтрэх</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
